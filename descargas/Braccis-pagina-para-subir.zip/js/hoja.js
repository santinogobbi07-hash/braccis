/* ============================================================
   Braccis - datos desde Google Sheets
   ------------------------------------------------------------
   Lee el Google Sheets publicado como CSV y lo mezcla con las
   prendas de js/productos.js. El sitio se dibuja primero con los
   datos locales y se actualiza cuando llega el Sheet: si Google
   tarda o falla, el visitante igual ve el catalogo.

   Pestaña "Productos" (una fila por prenda):
     id | codigo | nombre | categoria | precio | foto | visible | talles | descripcion | colores | fotos_color
     - "id" identifica la prenda. Si no existe en productos.js, es nueva.
     - Prenda nueva: el id se deja vacio y se arma solo con el nombre.
     - Celda vacia = se deja el dato que ya estaba.
     - visible = "no" oculta la prenda.

   Pestaña "Ajustes" (clave | valor):
     video_portada | portada.mp4   (archivo de la carpeta video/ o link https)
     catalogo_pdf  | enlace de Google Drive del PDF (vacio = docs/)

   El Sheet es publico y cualquiera con permiso de edicion lo cambia:
   todo lo que viene de ahi se valida aca y se escapa al mostrarse.
   ============================================================ */

const AJUSTES = {};
const ESPERA_MAXIMA_MS = 6000;

/* Convierte el texto de un CSV en una lista de filas.
   Respeta comillas ("Remera, basica"), comillas dobles escapadas ("") y
   saltos de linea de Windows. */
function leerCSV(texto) {
  const filas = [];
  let fila = [];
  let celda = "";
  let entreComillas = false;
  texto = String(texto || "").replace(/^﻿/, "");

  for (let i = 0; i < texto.length; i++) {
    const c = texto[i];
    if (entreComillas) {
      if (c === '"' && texto[i + 1] === '"') { celda += '"'; i++; }
      else if (c === '"') entreComillas = false;
      else celda += c;
    } else if (c === '"') {
      entreComillas = true;
    } else if (c === ",") {
      fila.push(celda); celda = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && texto[i + 1] === "\n") i++;
      fila.push(celda); celda = "";
      filas.push(fila); fila = [];
    } else {
      celda += c;
    }
  }
  if (celda !== "" || fila.length) { fila.push(celda); filas.push(fila); }

  // Se descartan las filas totalmente vacias
  return filas.filter(function (f) { return f.some(function (x) { return x.trim() !== ""; }); });
}

/* Pasa las filas a objetos usando la primera fila como titulos.
   "id (no tocar)" se lee como "id": solo cuenta la primera palabra. */
function filasAObjetos(filas) {
  if (!filas.length) return [];
  const titulos = filas[0].map(function (t) {
    return t.trim().toLowerCase().split(/[\s(]/)[0];
  });
  return filas.slice(1).map(function (f) {
    const o = {};
    titulos.forEach(function (t, i) { o[t] = (f[i] || "").trim(); });
    return o;
  });
}

/* Precio -> numero. Entiende el formato argentino y el de EE.UU., porque
   si en Google Sheets se le pone a la columna el tipo "Moneda", puede
   publicar cualquiera de los dos segun la configuracion regional:
     18500 · 18.500 · $ 18.500 · 18.500,50   (argentino)
     $18,500 · $18,500.00                    (EE.UU.)
   Regla: si aparecen punto y coma, el que esta mas a la derecha es el de
   los centavos. Si hay uno solo seguido de exactamente 3 digitos, es el
   de los miles (en ropa nadie pone precios con 3 decimales). */
function aNumero(texto) {
  let t = String(texto || "").replace(/[^\d.,]/g, "");
  if (!t) return null;

  const ultimoPunto = t.lastIndexOf(".");
  const ultimaComa = t.lastIndexOf(",");

  if (ultimoPunto !== -1 && ultimaComa !== -1) {
    const decimal = ultimoPunto > ultimaComa ? "." : ",";
    const miles = decimal === "." ? "," : ".";
    t = t.split(miles).join("").replace(decimal, ".");
  } else if (ultimoPunto !== -1 || ultimaComa !== -1) {
    const sep = ultimoPunto !== -1 ? "." : ",";
    const partes = t.split(sep);
    const sonMiles = partes.slice(1).every(function (p) { return p.length === 3; });
    t = sonMiles ? partes.join("") : partes.slice(0, -1).join("") + "." + partes[partes.length - 1];
  }

  const n = Number(t);
  return isFinite(n) && n > 0 ? Math.round(n * 100) / 100 : null;
}

/* Solo se aceptan nombres de archivo simples (sin carpetas ni links):
   asi nadie puede apuntar la foto a cualquier lado desde el Sheet. */
function archivoValido(nombre, extensiones) {
  const re = new RegExp("^[\\w\\-. ]+\\.(" + extensiones + ")$", "i");
  return re.test(nombre) && nombre.indexOf("..") === -1;
}

/* La columna "foto" acepta tres cosas:
     1. un nombre de archivo de img/prendas/       somos.jpg
     2. el link de "Compartir" de Google Drive      https://drive.google.com/file/d/.../view
     3. un link directo a una imagen                https://i.ibb.co/.../foto.jpg
   El link de Drive no es la imagen sino una pagina para verla, asi que se
   convierte a la direccion de la imagen en si (y ya achicada a 1200 px).
   Solo se aceptan links https: nada de "javascript:", "data:" ni "http:".
   Devuelve "" si no entiende lo que hay en la celda. */
function resolverFoto(valor) {
  const v = String(valor || "").trim();
  if (!v) return "";
  if (archivoValido(v, "jpe?g|png|webp")) return "img/prendas/" + v;

  const drive = v.match(
    /^https:\/\/(?:drive|docs)\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:[^#]*&)?id=|thumbnail\?(?:[^#]*&)?id=)([\w-]{20,})/
  );
  if (drive) return "https://lh3.googleusercontent.com/d/" + drive[1] + "=w1200";

  if (/^https:\/\/[^\s"'<>\\]+$/i.test(v)) return v;
  return "";
}

/* "Remera Luna Nueva" -> "remera-luna-nueva" (sin tildes ni simbolos) */
function armarId(nombre) {
  return String(nombre || "")
    .normalize("NFD").replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/* Las prendas nuevas se cargan sin id: se arma solo con el nombre, para
   que quien carga la planilla no tenga que inventarlo. Si ya existe (otra
   prenda con el mismo nombre), se le agrega -2, -3... Mientras no cambien
   el nombre ni el orden de las filas, el id queda siempre igual (importa
   para los carritos que ya la tienen guardada). */
function completarIds(filas) {
  const usados = {};
  PRODUCTOS.forEach(function (p) { usados[p.id] = true; });
  filas.forEach(function (f) { if (f.id) usados[f.id] = true; });
  filas.forEach(function (f) {
    if (f.id || !f.nombre) return;
    const base = armarId(f.nombre);
    if (!base) return;
    let id = base;
    for (let n = 2; usados[id]; n++) id = base + "-" + n;
    usados[id] = true;
    f.id = id;
  });
  return filas;
}

function categoriaDe(texto) {
  const t = texto.trim().toLowerCase();
  const c = CATEGORIAS.find(function (x) {
    return x.id === t || x.nombre.toLowerCase() === t;
  });
  return c ? c.id : "";
}

/* Mezcla una fila del Sheet con la prenda correspondiente */
function aplicarFila(f) {
  if (!f.id) return;
  let p = PRODUCTOS.find(function (x) { return x.id === f.id; });
  const nueva = !p;

  if (nueva) {
    // Una prenda nueva necesita al menos nombre y foto para mostrarse bien
    if (!f.nombre || !f.foto) return;
    p = { id: f.id, nombre: "", codigo: "", categoria: "", precio: null,
          descripcion: "", tela: "", talles: [], colores: [], foto: "",
          galeria: [], destacado: false, desdeHoja: true };
    PRODUCTOS.push(p);
  }

  if (f.nombre) p.nombre = f.nombre;
  if (f.codigo) p.codigo = f.codigo;
  if (f.descripcion) p.descripcion = f.descripcion;
  if (f.categoria && categoriaDe(f.categoria)) p.categoria = categoriaDe(f.categoria);

  const precio = aNumero(f.precio);
  if (precio !== null) p.precio = precio;

  const foto = resolverFoto(f.foto);
  if (foto) {
    p.foto = foto;
  } else if (nueva) {
    PRODUCTOS.pop();          // sin una foto valida, la prenda nueva no entra
    return;
  }

  if (f.talles) {
    p.talles = f.talles.split(/[,;]/).map(function (t) { return t.trim(); }).filter(Boolean);
  }

  // fotos_color: que foto mostrar al elegir cada color. Una por renglon o
  // separadas por coma, cada una "Color: foto" (la foto como en la columna
  // foto: nombre de archivo o enlace de Drive). Ej: "Negro: gio-3.jpg"
  if (f.fotos_color) {
    const fotos = {};
    f.fotos_color.split(/\s*[\n,;]\s*/).forEach(function (par) {
      const corte = par.indexOf(":");
      if (corte < 1) return;
      const color = par.slice(0, corte).trim().toLowerCase();
      const foto = resolverFoto(par.slice(corte + 1));
      if (color && !/^https?$/.test(color) && foto) fotos[color] = foto;
    });
    p.fotosColor = fotos;
  }

  // colores: "Negro, Blanco, Mostaza". Si un color ya tenia su muestra
  // (la bolita sacada del catalogo), se conserva; si es nuevo, va sin bolita.
  if (f.colores) {
    const antes = p.colores || [];
    p.colores = f.colores.split(/[,;]/).map(function (c) { return c.trim(); }).filter(Boolean)
      .map(function (nombre) {
        const igual = antes.find(function (c) { return c.nombre.toLowerCase() === nombre.toLowerCase(); });
        return { nombre: nombre, muestra: igual ? igual.muestra : "" };
      });
  }

  // visible: "si" se ve · "no" se oculta · "agotado" se ve con cartel y
  // sin poder comprarse (tambien acepta "sin stock")
  const visible = (f.visible || "").trim();
  p.oculto = /^(no|n|0|false|oculto)$/i.test(visible);
  p.agotado = /^(agotado|agotada|sin\s*stock)$/i.test(visible);
}

/* Descarga un CSV con tiempo maximo de espera */
function traerCSV(url) {
  const control = typeof AbortController !== "undefined" ? new AbortController() : null;
  const reloj = setTimeout(function () { if (control) control.abort(); }, ESPERA_MAXIMA_MS);
  return fetch(url, { signal: control ? control.signal : undefined, cache: "no-store" })
    .then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.text();
    })
    .finally(function () { clearTimeout(reloj); });
}

function cargarHoja() {
  const pedidos = [];

  if (EMPRESA.sheetProductos) {
    pedidos.push(traerCSV(EMPRESA.sheetProductos).then(function (texto) {
      completarIds(filasAObjetos(leerCSV(texto))).forEach(aplicarFila);
    }).catch(function () { /* sin Sheet: quedan los datos locales */ }));
  }

  if (EMPRESA.sheetAjustes) {
    pedidos.push(traerCSV(EMPRESA.sheetAjustes).then(function (texto) {
      leerCSV(texto).slice(1).forEach(function (f) {
        const clave = (f[0] || "").trim().toLowerCase();
        if (clave) AJUSTES[clave] = (f[1] || "").trim();
      });
    }).catch(function () {}));
  }

  Promise.all(pedidos).then(function () {
    if (pedidos.length && typeof redibujarCatalogo === "function") redibujarCatalogo();
    document.dispatchEvent(new CustomEvent("braccis:hoja-lista", { detail: AJUSTES }));
  });
}

/* ------------------------------------------------------------
   Video de portada (solo existe en index.html)
   ------------------------------------------------------------ */
function ponerVideoPortada(valor) {
  const video = document.querySelector(".hero__video");
  if (!video || !valor) return;

  // Respeta a quien pidio menos movimiento o esta ahorrando datos
  const menosMovimiento = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const ahorroDatos = navigator.connection && navigator.connection.saveData;
  if (menosMovimiento || ahorroDatos) return;

  let src = "";
  if (/^https:\/\/\S+$/i.test(valor)) src = valor;
  else if (archivoValido(valor, "mp4|webm")) src = "video/" + valor;
  if (!src) return;

  // El video arranca transparente (no oculto: Chrome pausa los videos que
  // no estan a la vista) y aparece recien cuando de verdad se reproduce.
  // Si falla, queda la foto de siempre.
  const hero = video.closest(".hero");
  function fallo() {
    hero.classList.remove("hero--con-video");
    video.removeAttribute("src");
  }
  video.muted = true;               // sin sonido: si no, el navegador no lo reproduce solo
  video.addEventListener("playing", function () {
    hero.classList.add("hero--con-video");
  }, { once: true });
  video.addEventListener("error", fallo, { once: true });
  video.src = src;
  const intento = video.play();
  if (intento && intento.catch) intento.catch(fallo);
}

/* ------------------------------------------------------------
   Catalogo PDF desde la planilla (pestaña Ajustes, clave catalogo_pdf)
   Braccis sube el PDF nuevo a su Google Drive, pega el enlace y todos
   los botones "Catálogo PDF" del sitio pasan a abrir ese archivo. Vacio
   = queda el PDF de docs/. Solo enlaces https (Drive u otro).
   ------------------------------------------------------------ */
function ponerCatalogoPdf(valor) {
  const v = String(valor || "").trim();
  if (!v) return;

  let link = "";
  const drive = v.match(/^https:\/\/(?:drive|docs)\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:[^#]*&)?id=)([\w-]{20,})/);
  if (drive) link = "https://drive.google.com/file/d/" + drive[1] + "/view";
  else if (/^https:\/\/[^\s"'<>\\]+$/i.test(v)) link = v;
  if (!link) return;

  document.querySelectorAll('a[href="' + EMPRESA.catalogoPdf + '"]').forEach(function (a) {
    a.href = link;
    a.removeAttribute("download");   // es otra pagina: se abre, no se descarga
    a.target = "_blank";
    a.rel = "noopener";
  });
}

document.addEventListener("braccis:hoja-lista", function (e) {
  ponerVideoPortada((e.detail || {}).video_portada);
  ponerCatalogoPdf((e.detail || {}).catalogo_pdf);
});

document.addEventListener("DOMContentLoaded", cargarHoja);
