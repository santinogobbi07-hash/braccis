/* ============================================================
   Braccis - catalogo
   Dibuja la grilla de prendas, los filtros por categoria,
   el buscador y el detalle de cada prenda en un modal.
   Los datos salen de js/productos.js
   ============================================================ */

let filtroCategoria = "todas";
let ultimoFoco = null;   // a donde vuelve el foco al cerrar la ficha
let filtroTexto = "";

/* Escapa un texto antes de meterlo en el HTML.
   Las fichas se arman como texto y se insertan con innerHTML, asi que
   cualquier dato que venga de productos.js tiene que pasar por aca. Si no,
   un nombre de prenda con simbolos raros (o copiado de un PDF cualquiera)
   podria romper la pagina o meter codigo. */
function esc(valor) {
  return String(valor === null || valor === undefined ? "" : valor)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

document.addEventListener("DOMContentLoaded", function () {
  dibujarDestacados();   // solo hace algo en la portada
  iniciarCatalogo();     // solo hace algo en catalogo.html
});

/* ============================================================
   PORTADA: prendas destacadas
   ============================================================ */
function dibujarDestacados() {
  const grilla = document.querySelector("[data-destacados]");
  if (!grilla) return;

  const disponibles = PRODUCTOS.filter(function (p) { return !p.oculto; });
  const destacados = disponibles.filter(function (p) { return p.destacado; }).slice(0, 8);
  const aMostrar = destacados.length ? destacados : disponibles.slice(0, 8);

  grilla.innerHTML = aMostrar.map(tarjetaProducto).join("");
  activarClicksDeTarjetas(grilla);
}

/* ============================================================
   CATALOGO: filtros + grilla
   ============================================================ */
function iniciarCatalogo() {
  const grilla = document.querySelector("[data-grilla]");
  if (!grilla) return;

  dibujarFiltros();
  dibujarGrilla();

  const buscador = document.querySelector("[data-buscador]");
  if (buscador) {
    buscador.addEventListener("input", function (e) {
      filtroTexto = e.target.value.trim().toLowerCase();
      dibujarGrilla();
    });
  }

  // Si se entra con ?categoria=blusas, arrancar filtrado.
  // Si la categoria del link no existe (un link viejo, un error de tipeo),
  // se muestra el catalogo completo en vez de dejar la pagina vacia.
  const params = new URLSearchParams(window.location.search);
  const cat = params.get("categoria");
  const existe = CATEGORIAS.some(function (c) { return c.id === cat; });
  if (cat && existe) {
    filtroCategoria = cat;
    marcarChipActivo();
    dibujarGrilla();
  }
}

function dibujarFiltros() {
  const cont = document.querySelector("[data-filtros]");
  if (!cont) return;

  // Solo mostramos categorias que efectivamente tienen prendas
  const usadas = CATEGORIAS.filter(function (c) {
    return PRODUCTOS.some(function (p) { return !p.oculto && p.categoria === c.id; });
  });

  const chips = [{ id: "todas", nombre: "Todas" }].concat(usadas);

  cont.innerHTML = chips.map(function (c) {
    const activo = c.id === filtroCategoria;
    return '<button class="chip" data-cat="' + esc(c.id) + '" aria-pressed="' + activo + '">' +
             esc(c.nombre) +
           '</button>';
  }).join("");

  cont.querySelectorAll(".chip").forEach(function (chip) {
    chip.addEventListener("click", function () {
      filtroCategoria = chip.dataset.cat;
      marcarChipActivo();
      dibujarGrilla();
    });
  });
}

function marcarChipActivo() {
  document.querySelectorAll("[data-filtros] .chip").forEach(function (chip) {
    chip.setAttribute("aria-pressed", chip.dataset.cat === filtroCategoria);
  });
}

function productosFiltrados() {
  return PRODUCTOS.filter(function (p) {
    if (p.oculto) return false;   // la ocultaron desde el Google Sheets
    const pasaCategoria = filtroCategoria === "todas" || p.categoria === filtroCategoria;
    const enTexto = (p.nombre + " " + p.codigo + " " + p.descripcion).toLowerCase();
    const pasaTexto = !filtroTexto || enTexto.indexOf(filtroTexto) !== -1;
    return pasaCategoria && pasaTexto;
  });
}

function dibujarGrilla() {
  const grilla = document.querySelector("[data-grilla]");
  const contador = document.querySelector("[data-contador]");
  if (!grilla) return;

  const lista = productosFiltrados();

  if (contador) {
    contador.textContent = lista.length === 1
      ? "1 prenda"
      : lista.length + " prendas";
  }

  if (!lista.length) {
    grilla.innerHTML = '<p class="vacio">No encontramos prendas con esa búsqueda.</p>';
    return;
  }

  grilla.innerHTML = lista.map(tarjetaProducto).join("");
  activarClicksDeTarjetas(grilla);
}

/* ============================================================
   Tarjeta de producto
   ============================================================ */
function tarjetaProducto(p) {
  const imagen = p.foto
    ? '<img src="' + esc(p.foto) + '" alt="' + esc(p.nombre) + '" loading="lazy">'
    : '<div class="producto__placeholder">' + esc(p.nombre.charAt(0).toUpperCase()) + '</div>';

  // Las bolitas son los circulitos recortados del catalogo. Los colores que
  // el PDF no dibuja no llevan bolita: aparecen solo en la ficha, por nombre.
  const puntos = (p.colores || []).filter(function (c) { return c.muestra; })
    .map(function (c) {
      return '<img class="punto-color" src="' + esc(c.muestra) + '" alt="' + esc(c.nombre) +
             '" title="' + esc(c.nombre) + '" loading="lazy">';
    }).join("");

  const precio = p.precio
    ? '<p class="producto__precio">' + esc(formatearPrecio(p.precio)) + '</p>'
    : (EMPRESA.sheetProductos ? '<p class="producto__precio producto__precio--consultar">Consultar precio</p>' : "");

  const codigo = p.codigo
    ? '<p class="producto__codigo">Cód. ' + esc(p.codigo) + '</p>'
    : "";

  return '' +
    '<article class="producto aparece visible" data-id="' + esc(p.id) + '" tabindex="0">' +
      '<div class="producto__figura">' + imagen +
        (p.agotado ? '<span class="producto__cartel-agotado">Agotado</span>' : '') +
      '</div>' +
      '<h3 class="producto__nombre">' + esc(p.nombre) + '</h3>' +
      codigo +
      precio +
      '<div class="producto__colores">' + puntos + '</div>' +
      // El talle es obligatorio: el boton abre la ficha para elegirlo
      (p.agotado
        // Sin stock: mismo lugar y tamano que el boton, para que la grilla no salte
        ? '<span class="btn btn--linea btn--chico producto__agregar producto__agregar--agotado" aria-hidden="true">Sin stock por ahora</span>'
        : '<button type="button" class="btn btn--linea btn--chico producto__agregar" data-agregar>Agregar al carrito</button>') +
    '</article>';
}

function activarClicksDeTarjetas(contenedor) {
  contenedor.querySelectorAll(".producto").forEach(function (tarjeta) {
    tarjeta.addEventListener("click", function (e) {
      const desdeBoton = !!e.target.closest("[data-agregar]");
      abrirModal(tarjeta.dataset.id, { elegirTalle: desdeBoton });
    });
    tarjeta.addEventListener("keydown", function (e) {
      if (e.target.closest("[data-agregar]")) return;   // el boton ya se activa solo
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        abrirModal(tarjeta.dataset.id);
      }
    });
  });
}

/* ============================================================
   Modal con el detalle de la prenda
   ============================================================ */
function abrirModal(id, opciones) {
  opciones = opciones || {};
  const p = PRODUCTOS.find(function (x) { return x.id === id; });
  const modal = document.querySelector("[data-modal]");
  if (!p || !modal) return;

  const imagen = p.foto
    ? '<img src="' + esc(p.foto) + '" alt="' + esc(p.nombre) + '" data-foto-grande>'
    : '<div class="producto__placeholder">' + esc(p.nombre.charAt(0).toUpperCase()) + '</div>';

  // Tira de miniaturas: la principal, las de la galeria y las fotos de
  // cada color cargadas en la planilla (sin repetir)
  const galeria = [p.foto].concat(p.galeria || [], fotoDeColor(p, null))
    .filter(function (src, i, lista) { return src && lista.indexOf(src) === i; });
  const miniaturas = galeria.length > 1
    ? '<div class="miniaturas">' + galeria.map(function (src, i) {
        return '<button class="miniatura" data-src="' + esc(src) + '"' +
               (i === 0 ? ' aria-current="true"' : '') +
               ' aria-label="Ver foto ' + (i + 1) + '">' +
                 '<img src="' + esc(src) + '" alt="" loading="lazy">' +
               '</button>';
      }).join("") + '</div>'
    : "";

  const filas = [];

  if (p.codigo) filas.push(fichaFila("Código", esc(p.codigo)));
  if (p.tela)   filas.push(fichaFila("Tela", esc(p.tela)));

  if (p.talles && p.talles.length) {
    // Botones con el mismo aspecto que antes: se elige uno para el carrito
    const talles = p.talles.map(function (t) {
      return '<button type="button" class="talle talle--elegible" data-talle="' + esc(t) +
             '" aria-pressed="false">' + esc(t) + '</button>';
    }).join("");
    filas.push(fichaFila("Talles", '<div class="talles" role="group" aria-label="Elegí un talle">' + talles + '</div>'));
  }

  if (p.colores && p.colores.length) {
    const colores = p.colores.map(function (c) {
      const bolita = c.muestra
        ? '<img class="punto-color" src="' + esc(c.muestra) + '" alt="" loading="lazy">'
        : "";
      return '<button type="button" class="color-item color-item--elegible" data-color="' +
             esc(c.nombre) + '" aria-pressed="false">' + bolita + esc(c.nombre) + '</button>';
    }).join("");
    filas.push(fichaFila("Colores", '<div class="colores-lista" role="group" aria-label="Elegí un color">' + colores + '</div>'));
  }

  // Cuantas unidades se agregan de una vez (mismos botones que el carrito).
  // El numero tambien se puede escribir, para pedidos grandes.
  if (!p.agotado) {
    filas.push(fichaFila("Cantidad",
      '<span class="carrito__cantidad cantidad-ficha">' +
        '<button type="button" data-cant="-1" aria-label="Una menos">−</button>' +
        '<input type="number" data-cant-valor value="1" min="1" max="999" step="1" inputmode="numeric" aria-label="Cantidad">' +
        '<button type="button" data-cant="1" aria-label="Una más">+</button>' +
      '</span>'));
  }

  const precio = p.precio
    ? '<p style="font-size:1.25rem;margin-top:10px">' + esc(formatearPrecio(p.precio)) + '</p>'
    : (EMPRESA.sheetProductos ? '<p class="producto__precio--consultar" style="margin-top:10px">Consultar precio</p>' : "");

  const descripcion = p.descripcion
    ? '<p class="bajada" style="margin-top:14px">' + esc(p.descripcion) + '</p>'
    : "";

  const cod = p.codigo ? " (cód. " + p.codigo + ")" : "";
  const consulta = p.agotado
    ? "¡Hola! Vi que la prenda " + p.nombre + cod + " está agotada. ¿Saben cuándo vuelve?"
    : "¡Hola! Me interesa la prenda " + p.nombre + cod + ". ¿Me pasan más info?";

  const compra = p.agotado
    ? '<p class="ficha__agotado">Agotado por ahora. Escribinos y te avisamos cuando vuelva.</p>'
    : '<div class="ficha__compra">' +
        '<button type="button" class="btn btn--primario" data-agregar-ficha>Agregar al carrito</button>' +
        '<p class="ficha__aviso" data-aviso-ficha role="status"></p>' +
        '<p class="ficha__mayorista" data-mayorista hidden>¿Comprás por cantidad? Tenemos precios mayoristas. ' +
          '<a data-mayorista-link href="#" target="_blank" rel="noopener">Consultalos por WhatsApp</a></p>' +
      '</div>';

  modal.querySelector("[data-modal-contenido]").innerHTML = '' +
    '<button class="modal__cerrar" data-cerrar aria-label="Cerrar">&times;</button>' +
    '<div class="modal__media">' +
      '<div class="modal__figura">' + imagen + '</div>' +
      miniaturas +
    '</div>' +
    '<div class="modal__info">' +
      '<h2 class="modal__nombre">' + esc(p.nombre) + '</h2>' +
      precio +
      descripcion +
      '<div class="ficha">' + filas.join("") + '</div>' +
      compra +
      '<a class="btn btn--wsp" style="margin-top:14px" href="' + esc(linkWhatsapp(consulta)) + '" target="_blank" rel="noopener">' +
        (p.agotado ? 'Consultar cuándo vuelve' : 'Consultar por WhatsApp') + '</a>' +
    '</div>';

  modal.classList.add("abierto");
  document.body.style.overflow = "hidden";

  // Se recuerda desde donde se abrio para devolver el foco al cerrar:
  // si no, quien navega con teclado vuelve al principio de la pagina
  ultimoFoco = document.activeElement;

  const cerrar = modal.querySelector("[data-cerrar]");
  cerrar.addEventListener("click", cerrarModal);
  cerrar.focus();

  activarMiniaturas(modal);
  activarCompra(modal, p);

  // Si se llego desde "Agregar al carrito" de la tarjeta, el foco va a los
  // talles: es lo primero que hay que elegir
  if (opciones.elegirTalle) {
    const primerTalle = modal.querySelector("[data-talle]");
    if (primerTalle) primerTalle.focus();
  }
}

/* Eleccion de talle y color, y alta en el carrito */
function activarCompra(modal, p) {
  const aviso = modal.querySelector("[data-aviso-ficha]");
  const boton = modal.querySelector("[data-agregar-ficha]");
  const valorCantidad = modal.querySelector("[data-cant-valor]");
  let talle = p.talles && p.talles.length === 1 ? p.talles[0] : "";
  let color = p.colores && p.colores.length === 1 ? p.colores[0].nombre : "";
  let cantidad = 1;
  const MAXIMO = 999;
  const mayorista = modal.querySelector("[data-mayorista]");
  const mayoristaLink = modal.querySelector("[data-mayorista-link]");

  // El boton dice cuantas se van a agregar: "Agregar 3 al carrito"
  function ponerCantidad(n) {
    cantidad = Math.min(MAXIMO, Math.max(1, Math.floor(Number(n)) || 1));
    if (valorCantidad) valorCantidad.value = cantidad;
    if (boton) boton.textContent = cantidad > 1 ? "Agregar " + cantidad + " al carrito" : "Agregar al carrito";
    avisarMayorista();
  }

  // Con muchas unidades (esta eleccion mas lo que ya hay en el carrito)
  // se ofrecen los precios mayoristas: el carrito suma a precio minorista
  function avisarMayorista() {
    if (!mayorista) return;
    const desde = Number(EMPRESA.mayoristaDesde) || 0;
    const enCarrito = typeof Carrito !== "undefined" ? Carrito.cantidadTotal() : 0;
    const mostrar = desde > 0 && cantidad + enCarrito >= desde;
    mayorista.hidden = !mostrar;
    if (mostrar) {
      const cod = p.codigo ? " (cód. " + p.codigo + ")" : "";
      mayoristaLink.href = linkWhatsapp("¡Hola! Quiero consultar precios mayoristas. Me interesa la prenda " +
        p.nombre + cod + (detalleEleccion() ? ", " + detalleEleccion() : "") + ": " + cantidad + " unidades.");
    }
  }

  // Si esa combinacion ya esta en el carrito, se avisa cuantas hay
  function avisarLasQueYaHay() {
    if (!aviso || typeof Carrito === "undefined") return;
    const ya = (talle || !(p.talles && p.talles.length)) ? Carrito.cuantas(p.id, talle, color) : 0;
    aviso.textContent = ya ? "Ya tenés " + ya + " en el carrito" + (detalleEleccion() ? " (" + detalleEleccion() + ")" : "") + "." : "";
  }

  function detalleEleccion() {
    return [talle ? "talle " + talle : "", color].filter(Boolean).join(" · ");
  }

  modal.querySelectorAll("[data-cant]").forEach(function (b) {
    b.addEventListener("click", function () {
      ponerCantidad(cantidad + Number(b.getAttribute("data-cant")));
    });
  });
  if (valorCantidad) {
    // Mientras escribe se actualiza el boton; al salir del campo se corrige
    // si puso algo invalido (vacio, 0, letras, mas de 999)
    valorCantidad.addEventListener("input", function () {
      const n = Math.floor(Number(valorCantidad.value));
      if (n >= 1) {
        cantidad = Math.min(MAXIMO, n);
        if (boton) boton.textContent = cantidad > 1 ? "Agregar " + cantidad + " al carrito" : "Agregar al carrito";
        avisarMayorista();
      }
    });
    valorCantidad.addEventListener("change", function () { ponerCantidad(valorCantidad.value); });
  }

  function marcar(selector, atributo, valor) {
    modal.querySelectorAll(selector).forEach(function (b) {
      b.setAttribute("aria-pressed", b.getAttribute(atributo) === valor ? "true" : "false");
    });
  }
  // Si hay una sola opcion, ya viene elegida
  if (talle) marcar("[data-talle]", "data-talle", talle);
  if (color) marcar("[data-color]", "data-color", color);
  if (!boton) return;          // agotada: no hay boton de compra
  avisarLasQueYaHay();
  avisarMayorista();

  modal.querySelectorAll("[data-talle]").forEach(function (b) {
    b.addEventListener("click", function () {
      talle = b.getAttribute("data-talle");
      marcar("[data-talle]", "data-talle", talle);
      avisarLasQueYaHay();
      avisarMayorista();
    });
  });
  modal.querySelectorAll("[data-color]").forEach(function (b) {
    b.addEventListener("click", function () {
      color = b.getAttribute("data-color");
      marcar("[data-color]", "data-color", color);
      mostrarFotoDeColor(modal, fotoDeColor(p, color));
      avisarLasQueYaHay();
      avisarMayorista();
    });
  });

  boton.addEventListener("click", function () {
    const hayTalles = p.talles && p.talles.length;
    const hayColores = p.colores && p.colores.length;
    if (hayTalles && !talle) { aviso.textContent = "Elegí un talle."; return; }
    if (hayColores && !color) { aviso.textContent = "Elegí un color."; return; }
    if (typeof Carrito === "undefined") return;
    const agregadas = cantidad;
    Carrito.agregar(p.id, talle, color, agregadas);
    mostrarCurva(aviso, agregadas, Carrito.variantes(p.id));
    ponerCantidad(1);
  });
}

/* Mensaje de "Listo" con la curva que se va armando de esta prenda:
     Listo, agregaste 1 al carrito. Ahora tenés en total 2 de este artículo:
     • 1x Talle M (Negro)
     • 1x Talle XL (Mostaza)
   Se arma con nodos de texto y <br> (nunca innerHTML): talles y colores
   pueden venir del Google Sheets. Reusa el mismo <p class="ficha__aviso">. */
function mostrarCurva(aviso, agregadas, variantes) {
  const total = variantes.reduce(function (n, v) { return n + v.cantidad; }, 0);
  aviso.textContent = "Listo, agregaste " + agregadas + " al carrito. " +
    "Ahora tenés en total " + total + " de este artículo:";
  variantes.forEach(function (v) {
    aviso.appendChild(document.createElement("br"));
    aviso.appendChild(document.createTextNode("• " + v.cantidad + "x " + nombreVariante(v)));
  });
}

// "Talle M (Negro)", "Talle 28", "Color Negro" o "Único" si no tiene ninguno
function nombreVariante(v) {
  if (v.talle && v.color) return "Talle " + v.talle + " (" + v.color + ")";
  if (v.talle) return "Talle " + v.talle;
  if (v.color) return "Color " + v.color;
  return "Único";
}

/* Foto de la prenda en un color ("Negro" -> foto con la remera negra),
   segun la columna fotos_color de la planilla. Con color null devuelve
   todas las fotos de colores. Si ese color no tiene foto, devuelve "". */
function fotoDeColor(p, color) {
  const fotos = p.fotosColor || {};
  if (color === null) return Object.keys(fotos).map(function (c) { return fotos[c]; });
  return fotos[String(color || "").toLowerCase()] || "";
}

/* Pone esa foto como grande y marca su miniatura */
function mostrarFotoDeColor(modal, src) {
  const grande = modal.querySelector("[data-foto-grande]");
  if (!src || !grande) return;
  grande.src = src;
  grande.style.visibility = "";
  modal.querySelectorAll(".miniatura").forEach(function (b) {
    if (b.dataset.src === src) b.setAttribute("aria-current", "true");
    else b.removeAttribute("aria-current");
  });
}

/* Al tocar una miniatura, cambia la foto grande de la ficha */
function activarMiniaturas(modal) {
  const grande = modal.querySelector("[data-foto-grande]");
  const botones = modal.querySelectorAll(".miniatura");
  if (!grande || !botones.length) return;

  botones.forEach(function (boton) {
    boton.addEventListener("click", function () {
      grande.src = boton.dataset.src;
      grande.style.visibility = "";      // por si la foto anterior no habia cargado
      botones.forEach(function (b) { b.removeAttribute("aria-current"); });
      boton.setAttribute("aria-current", "true");
    });
  });
}

function fichaFila(clave, valor) {
  return '<div class="ficha__fila">' +
           '<span class="ficha__clave">' + esc(clave) + '</span>' +
           '<span>' + valor + '</span>' +
         '</div>';
}

function cerrarModal() {
  const modal = document.querySelector("[data-modal]");
  if (!modal || !modal.classList.contains("abierto")) return;
  modal.classList.remove("abierto");
  document.body.style.overflow = "";
  if (ultimoFoco && document.contains(ultimoFoco)) ultimoFoco.focus();
  ultimoFoco = null;
}

// Cerrar con click en el fondo o con Escape
document.addEventListener("click", function (e) {
  const modal = document.querySelector("[data-modal]");
  if (modal && e.target === modal) cerrarModal();
});
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape") cerrarModal();
});

/* Vuelve a dibujar todo con los datos actuales. Lo llama js/hoja.js
   cuando llegan los precios y cambios del Google Sheets. */
function redibujarCatalogo() {
  dibujarDestacados();
  if (document.querySelector("[data-grilla]")) {
    dibujarFiltros();
    dibujarGrilla();
  }
}

/* Si una foto no carga (por ejemplo, un link mal copiado en el Google
   Sheets), en vez del icono de imagen rota se muestra el recuadro con la
   inicial de la prenda. Se escucha en "captura" porque el error de una
   imagen no sube por el documento. */
document.addEventListener("error", function (e) {
  const img = e.target;
  if (!img || img.tagName !== "IMG") return;

  const figura = img.closest(".producto__figura");
  if (figura) {
    const reemplazo = document.createElement("div");
    reemplazo.className = "producto__placeholder";
    reemplazo.textContent = (img.alt || "·").charAt(0).toUpperCase();
    img.replaceWith(reemplazo);
    return;
  }
  if (img.closest(".modal__figura, .miniatura, .carrito__foto")) {
    img.style.visibility = "hidden";
  }
}, true);
